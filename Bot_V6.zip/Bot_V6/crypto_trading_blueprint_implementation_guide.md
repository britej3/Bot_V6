# Crypto Trading Blueprint Implementation Guide

## Overview

This implementation guide provides detailed, step-by-step instructions for integrating the crypto trading blueprint specifications into the existing CryptoScalp AI codebase. Each section includes code examples, configuration details, and validation steps.

## Phase 1: Core Infrastructure Enhancement

### 1.1 Enhanced Data Pipeline Implementation

#### Step 1.1.1: Install Required Dependencies
```bash
# Add to requirements.txt
kafka-python==2.0.2
redis==4.5.4
dragonflydb==0.1.0
timescaledb==0.2.0
clickhouse-driver==0.2.4
```

#### Step 1.1.2: Implement Kafka Streaming Infrastructure
```python
# src/data_pipeline/kafka_streaming.py
from kafka import KafkaProducer, KafkaConsumer
import json
from typing import Dict, Any
import asyncio

class KafkaStreamingManager:
    """Kafka-based real-time data streaming manager"""

    def __init__(self, bootstrap_servers: list = None):
        self.bootstrap_servers = bootstrap_servers or ['localhost:9092']
        self.producer = None
        self.consumer = None

    async def initialize_producer(self):
        """Initialize Kafka producer"""
        self.producer = KafkaProducer(
            bootstrap_servers=self.bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode('utf-8'),
            acks='all',
            retries=5,
            retry_backoff_ms=1000
        )

    async def publish_market_data(self, topic: str, data: Dict[str, Any]):
        """Publish market data to Kafka topic"""
        try:
            future = await asyncio.get_event_loop().run_in_executor(
                None,
                self.producer.send,
                topic,
                data
            )
            record_metadata = future.get(timeout=10)
            print(f"Published to {topic}: {record_metadata}")
        except Exception as e:
            print(f"Error publishing to Kafka: {e}")

    async def consume_market_data(self, topic: str, group_id: str):
        """Consume market data from Kafka topic"""
        self.consumer = KafkaConsumer(
            topic,
            bootstrap_servers=self.bootstrap_servers,
            group_id=group_id,
            value_deserializer=lambda x: json.loads(x.decode('utf-8')),
            auto_offset_reset='latest'
        )

        for message in self.consumer:
            yield message.value
```

#### Step 1.1.3: Implement Redis/Dragonfly Caching Layer
```python
# src/data_pipeline/redis_cache.py
import redis
import json
from typing import Dict, Any, Optional
import time

class RedisCacheManager:
    """Redis/Dragonfly caching layer for sub-millisecond lookups"""

    def __init__(self, host: str = 'localhost', port: int = 6379):
        self.redis_client = redis.Redis(host=host, port=port, decode_responses=True)

    def cache_market_data(self, key: str, data: Dict[str, Any], ttl: int = 300):
        """Cache market data with TTL"""
        try:
            self.redis_client.setex(key, ttl, json.dumps(data))
        except Exception as e:
            print(f"Error caching data: {e}")

    def get_cached_data(self, key: str) -> Optional[Dict[str, Any]]:
        """Retrieve cached market data"""
        try:
            data = self.redis_client.get(key)
            return json.loads(data) if data else None
        except Exception as e:
            print(f"Error retrieving cached data: {e}")
            return None

    def cache_order_book(self, symbol: str, order_book: Dict[str, Any]):
        """Cache order book with high-frequency updates"""
        key = f"order_book:{symbol}"
        self.cache_market_data(key, order_book, ttl=60)  # 1-minute TTL

    def get_order_book(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get cached order book"""
        key = f"order_book:{symbol}"
        return self.get_cached_data(key)
```

### 1.2 ML Model Ensemble Expansion

#### Step 1.2.1: Implement Temporal Convolutional Network (TCN)
```python
# src/models/temporal_convolutional_network.py
import torch
import torch.nn as nn
from typing import List

class TemporalConvolutionalNetwork(nn.Module):
    """TCN for temporal pattern recognition in trading data"""

    def __init__(self, input_size: int, hidden_size: int, num_layers: int, output_size: int):
        super().__init__()

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        # TCN layers with dilated convolutions
        self.tcn_layers = nn.ModuleList()
        for i in range(num_layers):
            dilation = 2 ** i
            padding = (2 ** i) * 2  # Maintain sequence length
            self.tcn_layers.append(
                nn.Conv1d(
                    input_size if i == 0 else hidden_size,
                    hidden_size,
                    kernel_size=3,
                    padding=padding,
                    dilation=dilation
                )
            )
            self.tcn_layers.append(nn.ReLU())
            self.tcn_layers.append(nn.Dropout(0.2))

        self.output_layer = nn.Linear(hidden_size, output_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass through TCN"""
        # x shape: (batch_size, sequence_length, input_size)
        x = x.transpose(1, 2)  # (batch_size, input_size, sequence_length)

        for layer in self.tcn_layers:
            x = layer(x)

        # Global average pooling
        x = torch.mean(x, dim=2)  # (batch_size, hidden_size)
        x = self.output_layer(x)
        return x

class TCNTradingModel:
    """TCN wrapper for trading predictions"""

    def __init__(self, sequence_length: int = 100, input_size: int = 20):
        self.sequence_length = sequence_length
        self.input_size = input_size
        self.model = TemporalConvolutionalNetwork(
            input_size=input_size,
            hidden_size=64,
            num_layers=4,
            output_size=3  # Buy, Sell, Hold
        )
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=0.001)
        self.criterion = nn.CrossEntropyLoss()

    def predict(self, features: List[float]) -> int:
        """Make prediction from feature list"""
        if len(features) < self.input_size:
            features = [0.0] * (self.input_size - len(features)) + features

        x = torch.tensor([features[-self.input_size:]], dtype=torch.float32)
        with torch.no_grad():
            output = self.model(x)
            return torch.argmax(output, dim=1).item()

    def train_step(self, batch_features: torch.Tensor, batch_labels: torch.Tensor):
        """Single training step"""
        self.optimizer.zero_grad()
        outputs = self.model(batch_features)
        loss = self.criterion(outputs, batch_labels)
        loss.backward()
        self.optimizer.step()
        return loss.item()
```

#### Step 1.2.2: Implement TabNet Model
```python
# src/models/tabnet_model.py
import torch
import torch.nn as nn
import numpy as np
from typing import Tuple

class FeatureTransformer(nn.Module):
    """TabNet feature transformer"""

    def __init__(self, input_dim: int, hidden_dim: int):
        super().__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim

        self.feature_layers = nn.ModuleList()
        for _ in range(2):  # Two feature transformation steps
            self.feature_layers.append(
                nn.Sequential(
                    nn.Linear(input_dim, hidden_dim),
                    nn.BatchNorm1d(hidden_dim),
                    nn.ReLU(),
                    nn.Dropout(0.1)
                )
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.feature_layers[1](self.feature_layers[0](x))

class AttentiveTransformer(nn.Module):
    """TabNet attentive transformer for feature selection"""

    def __init__(self, input_dim: int, hidden_dim: int):
        super().__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim

        self.attention = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
            nn.Softmax(dim=1)
        )

    def forward(self, x: torch.Tensor, prior: torch.Tensor) -> torch.Tensor:
        attention_weights = self.attention(x)
        mask = attention_weights * prior
        return mask

class TabNet(nn.Module):
    """TabNet implementation for interpretable trading predictions"""

    def __init__(self, input_dim: int, output_dim: int, n_steps: int = 3):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.n_steps = n_steps

        self.initial_feature_transformer = FeatureTransformer(input_dim, 64)
        self.feature_transformers = nn.ModuleList([
            FeatureTransformer(input_dim, 64) for _ in range(n_steps)
        ])
        self.attentive_transformers = nn.ModuleList([
            AttentiveTransformer(input_dim, 64) for _ in range(n_steps)
        ])

        self.final_classifier = nn.Linear(64, output_dim)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Forward pass with feature importance"""
        feature_importance = []

        # Initial transformation
        features = self.initial_feature_transformer(x)
