"""
CryptoScalp AI - High-Frequency Cryptocurrency Trading System
"""

__version__ = "1.0.0"
__author__ = "CryptoScalp AI Team"